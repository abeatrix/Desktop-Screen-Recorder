# Desktop App - Screen Recorder
A simple desktop app built in HTML, CSS, and vanilla JavaScript on Electron that allows users to record their screen.

## DEMO
<div style="text-align:center">
  <img src="public/demo.gif"/>
</div>
